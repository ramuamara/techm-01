package testing

import (
	"fmt"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/suite"
	"testing"
)

type ModuleSuite struct {
	terraformOptions *terraform.Options
	fixturefolde     string
	suite.Suite
}

func TestInputOutput(t *testing.T) {
	suite.Run(t, new(ModuleSuite))
}

func (suite *ModuleSuite) SetupSuite() {

	fixtureDir := "./fixture"
	suite.fixturefolde = fixtureDir
	terraformOptions := &terraform.Options{

		TerraformDir: fixtureDir,
	}

	terraform.InitAndApply(suite.T(), terraformOptions)

	suite.terraformOptions = terraformOptions
	fmt.Println("This will run once before one suite test")
}

func (suite *ModuleSuite) TearDownSuite() {
	fmt.Println("This will run once after one suite test")
	terraform.Destroy(suite.T(), suite.terraformOptions)

}
func (a ModuleSuite) TestName() {
	actualOuputName := terraform.Output(a.T(), a.terraformOptions, "virtual_network_link_name")
	a.Contains("test.voyager-infra-test-centralus.private", actualOuputName)

}
/*
func (a ModuleSuite) TestId() {
	actualOutputId := terraform.Output(a.T(), a.terraformOptions, "virtual_network_link_id")
	a.Contains("test", actualOutputId)

}
*/
