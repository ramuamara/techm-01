const prompts = [
  {
    type: "list",
    name: "provider",
    message: "Please select the cloud provider",
    choices: [
      {
        value: "aws",
        name: "AWS",
      },
      {
        value: "azure",
        name: "Azure",
      },
      {
        value: "gcp",
        name: "GCP",
      },
    ],
  },
];

module.exports = prompts;
