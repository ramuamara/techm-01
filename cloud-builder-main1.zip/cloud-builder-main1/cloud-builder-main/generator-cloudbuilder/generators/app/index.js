const Generator = require("yeoman-generator");
const prompts = require("./prompts_app");

module.exports = class extends Generator {
  async prompting() {
    this.answers = await this.prompt(prompts);
  }

  default() {
    this.composeWith(require.resolve("../" + this.answers.provider));
  }
};
