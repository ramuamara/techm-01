const general = [
  {
    type: "string",
    name: "env",
    message: "Please enter the environment",
  },
  {
    type: "string",
    name: "region",
    message: "Please enter selected region",
  },
  {
    type: "string",
    name: "azs",
    message: "Please select the availability zones",
  },
  {
    type: "string",
    name: "product",
    message: "Please enter product name",
  },
  {
    type: "string",
    name: "app",
    message: "Please enter the application name",
  },
  {
    type: "list",
    name: "architecture",
    message: "Please select Architecture",
    choices: [
      {
        value: "ecs",
        name: "ECS-Fargate",
      },
      {
        value: "eks",
        name: "EKS-Fargate",
      },
    ],
  },
];

const ecsPrompts = [
  {
    type: "string",
    name: "cidr",
    message: "Please enter cidr",
  },
  {
    type: "string",
    name: "private_subnet",
    message: "Please enter private subnet",
  },
  {
    type: "string",
    name: "public_subnet",
    message: "Please enter public subnet",
  },
  {
    type: "string",
    name: "database_subnet",
    message: "Please enter database subnet",
  },
];

const eksPrompts = [
  {
    type: "string",
    name: "cidr",
    message: "Please enter cidr",
  },
  {
    type: "string",
    name: "private_subnet",
    message: "Please enter private subnet",
  },
  {
    type: "string",
    name: "public_subnet",
    message: "Please enter public subnet",
  },
  {
    type: "string",
    name: "database_subnet",
    message: "Please enter database subnet",
  },
];

module.exports = { general, ecsPrompts, eksPrompts };
