# terraform-azurerm-vnet


## Create a virtual network resource in azure

This module creates a resource group to manage related components logically.

## Usage

```hcl
module "resource_group" {
  source = "git::https://vcavsts.visualstudio.com/Project%20Voyager%20MVP/_git/voyager-module-vnet?version=GBmaster"
  name = "unit-test"
  create_rg = true
  environment = "dev"
  region = "centralus"
  tags = {
    role="unit-test"
 }
}

module "network" {
  source              = "../../"
  name                = "unit-test"
  resource_group_name = module.resource_group.resource_group_name
  region              = "centralus"
  cidr_range          = "10.0.0.0/16"
  subnet_prefixes     = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
  subnet_names        = ["subnet1", "subnet2", "subnet3"]
  environment         = "dev"

  tags = {
    role = "unit-test"
  }
}

# this should be output.tf
output "resource_group_name" {
  value = "${module.resource_group.resource_group_name}"
}

output "vnet_id" {
  value = "${module.network.vnet_id}"
}

```
