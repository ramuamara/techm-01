/*package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/gruntwork-io/terratest/modules/test-structure"
)

func TestTerraformAKS(t *testing.T) {
	t.Parallel()

	fixtureFolder := "./fixture"

	// Deploy the example
	test_structure.RunTestStage(t, "setup", func() {
		terraformOptions := configureTerraformOptions(t, fixtureFolder)

		// Save the options so later test stages can use them
		test_structure.SaveTerraformOptions(t, fixtureFolder, terraformOptions)

		// This will init and apply the resources and fail the test if there are any errors
		terraform.InitAndApply(t, terraformOptions)
	})

	// Check whether the length of output meets the requirement
	test_structure.RunTestStage(t, "validate", func() {
		terraformOptions := test_structure.LoadTerraformOptions(t, fixtureFolder)

		string := terraform.Output(t, terraformOptions, "aks_id")
		if len(string) <= 0 {
			t.Fatal("Wrong output")
		}
	})

	// At the end of the test, clean up any resources that were created
	test_structure.RunTestStage(t, "teardown", func() {
		terraformOptions := test_structure.LoadTerraformOptions(t, fixtureFolder)
		terraform.Destroy(t, terraformOptions)
	})

}

func configureTerraformOptions(t *testing.T, fixtureFolder string) *terraform.Options {

	terraformOptions := &terraform.Options{
		// The path to where our Terraform code is located
		TerraformDir: fixtureFolder,

		// Variables to pass to our Terraform code using -var options
		//Vars: map[string]interface{}{},
	}

	return terraformOptions
}


func (a moduleGroupSuite) TestOne() {
	actualOuputName := terraform.Output(a.T(), a.terraformOptions, "aks_name")
	a.Equal("voyager-infra-dev-aks", actualOuputName)
}
*/
package testing

import (
	"fmt"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/suite"
	"testing"
)

type ModuleSuite struct {
	terraformOptions *terraform.Options
	fixturefolde     string
	suite.Suite
}

func TestInputOutput(t *testing.T) {
	suite.Run(t, new(ModuleSuite))
}

//func (suite *resourcegroupSuite) TearDownTest() {
//	fmt.Println("This will run after every test")
//}
func (suite *ModuleSuite) SetupSuite() {

	fixtureDir := "./fixture"
	suite.fixturefolde = fixtureDir
	terraformOptions := &terraform.Options{

		TerraformDir: fixtureDir,
	}

	terraform.InitAndApply(suite.T(), terraformOptions)

	suite.terraformOptions = terraformOptions
	fmt.Println("This will run once before one suite test")
}

func (suite *ModuleSuite) TearDownSuite() {
	fmt.Println("This will run once after one suite test")
	terraform.Destroy(suite.T(), suite.terraformOptions)

}

//func (t *inputoutsuite) SetupTest() {
//	fmt.Println("this is run before every test")
//}

func (a ModuleSuite) TestOne() {
	actualOuputName := terraform.Output(a.T(), a.terraformOptions, "aks_name")
	a.Equal("voyager-infra-dev-aks", actualOuputName)
}

func (a ModuleSuite) TestTwo() {
	actualOuputName := terraform.Output(a.T(), a.terraformOptions, "location")
	a.Equal("centralus", actualOuputName)
}