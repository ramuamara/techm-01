const Generator = require("yeoman-generator");
const prompts = require("./prompts_aws");
const fs = require("fs");

module.exports = class extends Generator {
  async prompting() {
    const answersGeneral = await this.prompt(prompts.general);
    const answersArchitecture = await this.prompt(
      answersGeneral.architecture === "ecs"
        ? prompts.ecsPrompts
        : prompts.eksPrompts
    );

    this.answers = {
      provider: "aws",
      ...answersGeneral,
      ...answersArchitecture,
    };
  }

  default() {
    this.outputFolderName = `${this.answers.app}-iac`;
  }

  writing() {
    //Copy entire template folder
    this.fs.copy(
      this.templatePath("cloudbuilder-aws/cloudbuilder"),
      this.destinationPath(this.outputFolderName),
      {
        globOptions: { dot: true },
      }
    );

    //Copy core folder to root of output folder
    this.fs.copy(
      this.templatePath(
        `cloudbuilder-aws/cloudbuilder/architecture/${this.answers.architecture}-fargate`
      ),
      this.destinationPath(this.outputFolderName),
      {
        globOptions: { dot: true },
      }
    );

    //Populate main.tf with values
    this.fs.copyTpl(
      this.templatePath(
        `cloudbuilder-aws/cloudbuilder/architecture/${this.answers.architecture}-fargate/main.tf.tpl`
      ),
      this.destinationPath(`${this.outputFolderName}/main.tf`),
      this.answers
    );

    //Delete template file
    this.fs.delete(`${this.outputFolderName}/main.tf.tpl`);
  }

  end() {
    //Delete architecture folder
    fs.rmSync(this.destinationPath(`${this.outputFolderName}/architecture`), {
      recursive: true,
      force: true,
    });
  }
};
